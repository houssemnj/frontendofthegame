# Enhanced Trivia Game Documentation

## Project Overview

This document provides comprehensive documentation for the Enhanced Trivia Game, a multiplayer trivia application inspired by Kalak.gg but with significant improvements. The game features real-time AI-generated questions and supports up to 10 players simultaneously.

## Table of Contents

1. [Features and Improvements](#features-and-improvements)
2. [System Architecture](#system-architecture)
3. [Technologies Used](#technologies-used)
4. [Installation and Setup](#installation-and-setup)
5. [Deployment](#deployment)
6. [API Documentation](#api-documentation)
7. [Future Enhancements](#future-enhancements)

## Features and Improvements

### Core Features

- **Multiplayer Support**: Accommodates up to 10 players simultaneously (compared to Kalak.gg's 5-player limit)
- **Real-time AI Question Generation**: Dynamic questions created on-demand rather than from a static database
- **Room-based Game System**: Players can create and join game rooms via room IDs
- **Customizable Game Settings**: Adjustable round time, number of rounds, and player limits
- **Multiple Categories**: Various trivia categories including general knowledge, science, history, and more
- **Real-time Updates**: Instant feedback on player actions and game state changes
- **Responsive Design**: Works seamlessly across desktop and mobile devices

### Improvements Over Kalak.gg

| Feature | Kalak.gg | Enhanced Trivia Game |
|---------|----------|----------------------|
| Player Limit | 5 players | 10 players |
| Question Source | Static database | Real-time AI generation |
| Categories | Limited set | Expandable with AI capabilities |
| UI Responsiveness | Basic | Fully responsive design |
| Game Customization | Limited | Extensive settings control |
| Scalability | Limited | Designed for horizontal scaling |

## System Architecture

The application follows a modern web architecture with clear separation of concerns:

### Frontend (React.js)
- **Home Page**: User registration and room creation/joining
- **Lobby Page**: Waiting room with player list and game settings
- **Game Page**: Question display, answer submission, and real-time scoring
- **Results Page**: Final scores and rankings

### Backend (Node.js)
- **Socket.io Server**: Handles real-time communication
- **Room Management**: Creates and manages game rooms
- **Game Logic**: Controls game flow, scoring, and state management
- **API Endpoints**: Provides data access for the frontend

### AI Service (Python/FastAPI)
- **Question Generation**: Creates trivia questions on demand
- **Category Management**: Supports multiple question categories
- **Difficulty Adjustment**: Adapts question difficulty based on settings

## Technologies Used

### Frontend
- React.js for UI components
- Socket.io client for real-time communication
- React Router for navigation
- Styled Components for styling
- Vite for build tooling

### Backend
- Node.js with Express for the server
- Socket.io for bidirectional communication
- MongoDB (configured but not active in current deployment)
- Axios for HTTP requests

### AI Service
- Python with FastAPI
- OpenAI integration (configured for future use)
- Uvicorn ASGI server

## Installation and Setup

### Prerequisites
- Node.js (v14+)
- Python (v3.8+)
- npm or yarn

### Local Development Setup

1. **Clone the repository**
   ```
   git clone <repository-url>
   cd trivia-game
   ```

2. **Backend Setup**
   ```
   cd backend
   npm install
   cp .env.example .env
   npm start
   ```

3. **AI Service Setup**
   ```
   cd ai-service
   pip install -r requirements.txt
   python -m uvicorn app:app --reload
   ```

4. **Frontend Setup**
   ```
   cd frontend
   npm install
   npm run dev
   ```

5. **Running the Complete Application**
   ```
   # From the project root
   ./run-multiplayer-test.sh
   ```

## Deployment

The application is deployed and accessible at:

- **Frontend**: https://tnzjiytw.manus.space
- **Backend API**: 3001-ij7fhc53r8tezwucy75l4-167c4dde.manus.computer

### Deployment Process

1. Build the frontend for production:
   ```
   cd frontend
   npm run build
   ```

2. Start the backend and AI services in production mode:
   ```
   ./start-production.sh
   ```

3. The application uses environment-specific configuration files (.env.production) for production settings.

## API Documentation

### Socket.io Events

#### Client to Server

| Event | Description | Parameters |
|-------|-------------|------------|
| `register` | Register a new user | `{ username }` |
| `create-room` | Create a new game room | `{ settings }` |
| `join-room` | Join an existing room | `{ roomId }` |
| `start-game` | Start the game (host only) | `{ roomId }` |
| `submit-answer` | Submit an answer | `{ roomId, answer }` |
| `leave-room` | Leave the current room | `{ roomId }` |

#### Server to Client

| Event | Description | Data |
|-------|-------------|------|
| `player-joined` | New player joined | `{ user, room }` |
| `player-left` | Player left the room | `{ playerId, room }` |
| `game-started` | Game has started | Game state object |
| `round-started` | New round started | Round state object |
| `round-ended` | Round has ended | Results object |
| `game-ended` | Game has ended | Final results object |
| `player-answered` | Player submitted answer | `{ playerId }` |

### REST API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Health check |
| `/api/rooms` | GET | List available rooms |

## Future Enhancements

1. **Authentication System**: User accounts and persistent profiles
2. **Leaderboards**: Global and friend-based leaderboards
3. **Custom Categories**: Allow users to create custom question categories
4. **Advanced Game Modes**: Team-based play and tournament modes
5. **Enhanced AI Integration**: More sophisticated question generation with learning capabilities
6. **Mobile Applications**: Native mobile apps for iOS and Android
7. **Internationalization**: Support for multiple languages

---

This documentation provides a comprehensive overview of the Enhanced Trivia Game, its features, architecture, and technical implementation. For any questions or issues, please contact the development team.
