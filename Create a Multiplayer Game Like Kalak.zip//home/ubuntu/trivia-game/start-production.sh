#!/bin/bash

# Production deployment script for the enhanced trivia game
# This script prepares and starts both backend and AI service in production mode

echo "=== Enhanced Trivia Game Production Deployment ==="

# Set environment to production
export NODE_ENV=production

# Start the AI service
cd /home/ubuntu/trivia-game/ai-service
echo "Starting AI Question Service in production mode..."
uvicorn app:app --host 0.0.0.0 --port 5000 &
AI_PID=$!

# Wait for AI service to start
sleep 3
echo "AI Question Service started with PID: $AI_PID"

# Start the backend server
cd /home/ubuntu/trivia-game/backend
echo "Starting Backend Server in production mode..."
node server.js &
BACKEND_PID=$!

echo "Backend Server started with PID: $BACKEND_PID"
echo "Both services are now running in production mode!"

# Keep script running
wait
