#!/bin/bash

# This script runs a comprehensive test for the multiplayer functionality
# It starts both backend and frontend services and provides instructions for testing

echo "=== Enhanced Trivia Game Multiplayer Test ==="
echo "This script will help test the game with up to 10 players"

# Start the backend services
cd /home/ubuntu/trivia-game
echo "Starting backend services (API and AI Question Service)..."
./start-services.sh &
BACKEND_PID=$!

# Wait for backend to start
sleep 5
echo "Backend services started successfully"

# Start the frontend development server
cd /home/ubuntu/trivia-game/frontend
echo "Starting frontend development server..."
npm run dev &
FRONTEND_PID=$!

# Wait for frontend to start
sleep 5
echo "Frontend server started successfully"

# Display testing instructions
echo ""
echo "=== Testing Instructions ==="
echo "1. Open http://localhost:3000 in your browser"
echo "2. Enter your name and create a new game room"
echo "3. Configure the room for up to 10 players"
echo "4. Copy the room ID shown in the lobby"
echo "5. Open additional browser windows/tabs and join using the room ID"
echo "6. Test with different numbers of players (2, 5, and up to 10)"
echo "7. Verify that all players can see questions, submit answers, and view results"
echo "8. Check that scores are tracked correctly"
echo "9. Verify the end-game results screen shows proper rankings"
echo ""
echo "The game should support up to 10 players simultaneously, exceeding Kalak.gg's 5-player limit"
echo "Real-time AI questions should be delivered to all players simultaneously"
echo ""
echo "Press Ctrl+C to stop all services when testing is complete"

# Keep the script running
wait $BACKEND_PID $FRONTEND_PID
