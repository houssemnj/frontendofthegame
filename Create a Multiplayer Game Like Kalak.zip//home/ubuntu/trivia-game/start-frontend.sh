#!/bin/bash

# Start the frontend development server
cd /home/ubuntu/trivia-game/frontend
echo "Starting frontend development server..."
npm run dev &
FRONTEND_PID=$!

# Wait for frontend to start
sleep 5
echo "Frontend server started at http://localhost:3000"

echo "To test the multiplayer functionality:"
echo "1. Open http://localhost:3000 in your browser"
echo "2. Create a game room with up to 10 players"
echo "3. Copy the room ID"
echo "4. Open additional browser windows/tabs and join using the room ID"
echo "5. Test the complete game flow with multiple players"

# Keep the script running
echo "Press Ctrl+C to stop the frontend server when testing is complete"
wait $FRONTEND_PID
