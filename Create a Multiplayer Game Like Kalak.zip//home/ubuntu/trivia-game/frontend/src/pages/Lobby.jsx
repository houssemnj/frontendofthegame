import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { useSocket } from '../context/SocketContext';
import { useGame } from '../context/GameContext';

const LobbyContainer = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  padding: 20px;
  background: linear-gradient(135deg, #1a73e8 0%, #0d47a1 100%);
`;

const LobbyCard = styled.div`
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
  padding: 2rem;
  margin: 2rem auto;
  width: 100%;
  max-width: 800px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
`;

const Title = styled.h1`
  font-size: 1.8rem;
  color: #333;
  margin: 0;
`;

const RoomInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  background-color: #f1f1f1;
  padding: 0.5rem 1rem;
  border-radius: 8px;
`;

const RoomId = styled.span`
  font-weight: bold;
  font-family: monospace;
  font-size: 1.2rem;
`;

const CopyButton = styled.button`
  background-color: transparent;
  border: none;
  cursor: pointer;
  color: #1a73e8;
  font-weight: bold;
  padding: 5px;
  
  &:hover {
    text-decoration: underline;
  }
`;

const PlayersSection = styled.div`
  margin-bottom: 2rem;
`;

const PlayersGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 1rem;
  margin-top: 1rem;
`;

const PlayerCard = styled.div`
  background-color: ${props => props.isHost ? '#fff8e1' : '#f5f5f5'};
  border: 2px solid ${props => props.isHost ? '#f8c630' : '#e0e0e0'};
  border-radius: 8px;
  padding: 1rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const PlayerAvatar = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: #1a73e8;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
`;

const PlayerName = styled.div`
  font-weight: ${props => props.isHost ? 'bold' : 'normal'};
`;

const HostBadge = styled.span`
  background-color: #f8c630;
  color: #333;
  font-size: 0.7rem;
  padding: 2px 5px;
  border-radius: 4px;
  margin-left: 5px;
`;

const SettingsSection = styled.div`
  margin-bottom: 2rem;
`;

const SettingsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 1rem;
  margin-top: 1rem;
`;

const SettingItem = styled.div`
  background-color: #f5f5f5;
  border-radius: 8px;
  padding: 1rem;
`;

const SettingLabel = styled.div`
  font-size: 0.9rem;
  color: #666;
  margin-bottom: 0.5rem;
`;

const SettingValue = styled.div`
  font-weight: bold;
  font-size: 1.1rem;
`;

const CategoriesSection = styled.div`
  margin-bottom: 2rem;
`;

const CategoriesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 0.5rem;
  margin-top: 1rem;
`;

const CategoryItem = styled.div`
  background-color: ${props => props.selected ? '#e3f2fd' : '#f5f5f5'};
  border: 2px solid ${props => props.selected ? '#1a73e8' : 'transparent'};
  border-radius: 8px;
  padding: 0.8rem;
  text-align: center;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background-color: ${props => props.selected ? '#e3f2fd' : '#e8e8e8'};
  }
`;

const ButtonsContainer = styled.div`
  display: flex;
  justify-content: space-between;
  gap: 1rem;
`;

const Button = styled.button`
  padding: 12px 24px;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: bold;
  cursor: pointer;
  transition: background-color 0.3s;
`;

const StartButton = styled(Button)`
  background-color: #f8c630;
  color: #333;
  
  &:hover {
    background-color: #e0b01f;
  }
  
  &:disabled {
    background-color: #f5f5f5;
    color: #999;
    cursor: not-allowed;
  }
`;

const LeaveButton = styled(Button)`
  background-color: #f1f1f1;
  color: #333;
  
  &:hover {
    background-color: #e5e5e5;
  }
`;

const ErrorMessage = styled.div`
  color: #e53935;
  margin-top: 1rem;
  text-align: center;
`;

const Lobby = () => {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const { socket, user, leaveRoom, startGame } = useSocket();
  const { room, setRoom, error, setError, loading, setLoading } = useGame();
  const [selectedCategories, setSelectedCategories] = useState(['general']);
  
  const categories = [
    { id: 'general', name: 'General Knowledge' },
    { id: 'science', name: 'Science' },
    { id: 'history', name: 'History' },
    { id: 'geography', name: 'Geography' },
    { id: 'entertainment', name: 'Entertainment' },
    { id: 'sports', name: 'Sports' }
  ];
  
  useEffect(() => {
    if (!socket || !user) {
      navigate('/');
      return;
    }
    
    // Join room on component mount
    const joinGameRoom = async () => {
      try {
        const response = await socket.emit('join-room', { roomId }, (response) => {
          if (response.success) {
            setRoom(response.room);
          } else {
            setError(response.error || 'Failed to join room');
            navigate('/');
          }
        });
      } catch (err) {
        setError(err.message || 'An error occurred');
        navigate('/');
      }
    };
    
    joinGameRoom();
    
    // Listen for game started event
    socket.on('game-started', () => {
      navigate(`/game/${roomId}`);
    });
    
    return () => {
      socket.off('game-started');
    };
  }, [socket, user, roomId, navigate, setRoom, setError]);
  
  const handleCopyRoomId = () => {
    navigator.clipboard.writeText(roomId);
  };
  
  const handleCategoryToggle = (categoryId) => {
    if (room?.hostId !== user?.id) return;
    
    setSelectedCategories(prev => {
      if (prev.includes(categoryId)) {
        return prev.filter(id => id !== categoryId);
      } else {
        return [...prev, categoryId];
      }
    });
  };
  
  const handleStartGame = async () => {
    if (!room || room.hostId !== user?.id) return;
    
    setLoading(true);
    setError('');
    
    try {
      await startGame(roomId);
    } catch (err) {
      setError(err.message || 'Failed to start game');
      setLoading(false);
    }
  };
  
  const handleLeaveRoom = async () => {
    try {
      await leaveRoom(roomId);
      navigate('/');
    } catch (err) {
      setError(err.message || 'Failed to leave room');
    }
  };
  
  if (!room) {
    return (
      <LobbyContainer>
        <LobbyCard>
          <Title>Loading lobby...</Title>
        </LobbyCard>
      </LobbyContainer>
    );
  }
  
  const isHost = user?.id === room.hostId;
  const canStartGame = isHost && room.players.length >= 2;
  
  return (
    <LobbyContainer>
      <LobbyCard>
        <Header>
          <Title>Game Lobby</Title>
          <RoomInfo>
            <span>Room ID:</span>
            <RoomId>{roomId}</RoomId>
            <CopyButton onClick={handleCopyRoomId}>Copy</CopyButton>
          </RoomInfo>
        </Header>
        
        <PlayersSection>
          <h2>Players ({room.players.length}/{room.settings.maxPlayers})</h2>
          <PlayersGrid>
            {room.players.map(player => (
              <PlayerCard key={player.id} isHost={player.id === room.hostId}>
                <PlayerAvatar>{player.username.charAt(0).toUpperCase()}</PlayerAvatar>
                <PlayerName isHost={player.id === room.hostId}>
                  {player.username}
                  {player.id === room.hostId && <HostBadge>Host</HostBadge>}
                </PlayerName>
              </PlayerCard>
            ))}
            {Array.from({ length: room.settings.maxPlayers - room.players.length }).map((_, index) => (
              <PlayerCard key={`empty-${index}`} style={{ opacity: 0.3 }}>
                <PlayerAvatar>?</PlayerAvatar>
                <PlayerName>Waiting...</PlayerName>
              </PlayerCard>
            ))}
          </PlayersGrid>
        </PlayersSection>
        
        <SettingsSection>
          <h2>Game Settings</h2>
          <SettingsGrid>
            <SettingItem>
              <SettingLabel>Max Players</SettingLabel>
              <SettingValue>{room.settings.maxPlayers}</SettingValue>
            </SettingItem>
            <SettingItem>
              <SettingLabel>Round Time</SettingLabel>
              <SettingValue>{room.settings.roundTime} seconds</SettingValue>
            </SettingItem>
            <SettingItem>
              <SettingLabel>Number of Rounds</SettingLabel>
              <SettingValue>{room.settings.rounds}</SettingValue>
            </SettingItem>
          </SettingsGrid>
        </SettingsSection>
        
        <CategoriesSection>
          <h2>Categories {!isHost && '(Host Selection)'}</h2>
          <CategoriesGrid>
            {categories.map(category => (
              <CategoryItem 
                key={category.id}
                selected={selectedCategories.includes(category.id)}
                onClick={() => handleCategoryToggle(category.id)}
                style={{ cursor: isHost ? 'pointer' : 'default' }}
              >
                {category.name}
              </CategoryItem>
            ))}
          </CategoriesGrid>
        </CategoriesSection>
        
        <ButtonsContainer>
          <LeaveButton onClick={handleLeaveRoom}>Leave Room</LeaveButton>
          {isHost && (
            <StartButton 
              onClick={handleStartGame} 
              disabled={!canStartGame || loading}
            >
              {loading ? 'Starting...' : 'Start Game'}
            </StartButton>
          )}
        </ButtonsContainer>
        
        {error && <ErrorMessage>{error}</ErrorMessage>}
        {!isHost && <div style={{ textAlign: 'center', marginTop: '1rem' }}>Waiting for host to start the game...</div>}
        {isHost && !canStartGame && <div style={{ textAlign: 'center', marginTop: '1rem' }}>Need at least 2 players to start</div>}
      </LobbyCard>
    </LobbyContainer>
  );
};

export default Lobby;
