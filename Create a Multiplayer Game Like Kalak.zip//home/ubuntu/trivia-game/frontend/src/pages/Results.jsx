import React, { useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import styled from 'styled-components';
import { useSocket } from '../context/SocketContext';
import { useGame } from '../context/GameContext';

const ResultsContainer = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  padding: 20px;
  background: linear-gradient(135deg, #1a73e8 0%, #0d47a1 100%);
`;

const ResultsCard = styled.div`
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
  padding: 2rem;
  margin: 2rem auto;
  width: 100%;
  max-width: 800px;
`;

const Title = styled.h1`
  font-size: 2rem;
  text-align: center;
  margin-bottom: 2rem;
  color: #333;
`;

const Subtitle = styled.h2`
  font-size: 1.5rem;
  text-align: center;
  margin-bottom: 2rem;
  color: #666;
`;

const LeaderboardContainer = styled.div`
  margin-bottom: 2rem;
`;

const PlayerRow = styled.div`
  display: flex;
  align-items: center;
  padding: 1rem;
  margin-bottom: 0.5rem;
  background-color: ${props => props.isWinner ? '#fff8e1' : '#f5f5f5'};
  border-left: 5px solid ${props => props.isWinner ? '#f8c630' : 'transparent'};
  border-radius: 8px;
`;

const Position = styled.div`
  font-size: 1.5rem;
  font-weight: bold;
  width: 40px;
  text-align: center;
`;

const PlayerAvatar = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: #1a73e8;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  margin: 0 1rem;
`;

const PlayerName = styled.div`
  flex: 1;
  font-size: 1.2rem;
  font-weight: ${props => props.isWinner ? 'bold' : 'normal'};
`;

const PlayerScore = styled.div`
  font-size: 1.5rem;
  font-weight: bold;
  color: ${props => props.isWinner ? '#f8c630' : '#333'};
`;

const WinnerTrophy = styled.span`
  font-size: 1.5rem;
  margin-left: 0.5rem;
  color: #f8c630;
`;

const ButtonsContainer = styled.div`
  display: flex;
  justify-content: center;
  gap: 1rem;
  margin-top: 2rem;
`;

const Button = styled.button`
  padding: 12px 24px;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: bold;
  cursor: pointer;
  transition: background-color 0.3s;
`;

const PrimaryButton = styled(Button)`
  background-color: #f8c630;
  color: #333;
  
  &:hover {
    background-color: #e0b01f;
  }
`;

const SecondaryButton = styled(Button)`
  background-color: #f1f1f1;
  color: #333;
  
  &:hover {
    background-color: #e5e5e5;
  }
`;

const StyledLink = styled(Link)`
  text-decoration: none;
`;

const Results = () => {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const { socket, user, leaveRoom } = useSocket();
  const { room, gameState, finalResults, resetGame } = useGame();
  
  useEffect(() => {
    if (!socket || !user || !room || !finalResults) {
      navigate('/');
      return;
    }
    
    // Clean up game state when leaving
    return () => {
      resetGame();
    };
  }, [socket, user, room, finalResults, navigate, resetGame]);
  
  const handlePlayAgain = () => {
    navigate(`/lobby/${roomId}`);
  };
  
  const handleLeaveRoom = async () => {
    try {
      await leaveRoom(roomId);
      resetGame();
      navigate('/');
    } catch (err) {
      console.error('Failed to leave room:', err);
    }
  };
  
  if (!room || !gameState || !finalResults) {
    return (
      <ResultsContainer>
        <ResultsCard>
          <div style={{ textAlign: 'center' }}>Loading results...</div>
        </ResultsCard>
      </ResultsContainer>
    );
  }
  
  // Sort players by score
  const sortedPlayers = Object.entries(finalResults.scores)
    .map(([playerId, score]) => {
      const player = room.players.find(p => p.id === playerId);
      return {
        id: playerId,
        name: player ? player.username : 'Unknown Player',
        score
      };
    })
    .sort((a, b) => b.score - a.score);
  
  const winner = sortedPlayers[0];
  const isCurrentUserWinner = winner.id === user.id;
  
  return (
    <ResultsContainer>
      <ResultsCard>
        <Title>Game Results</Title>
        <Subtitle>
          {isCurrentUserWinner 
            ? 'Congratulations! You won! 🎉' 
            : `${winner.name} wins! 🏆`}
        </Subtitle>
        
        <LeaderboardContainer>
          {sortedPlayers.map((player, index) => (
            <PlayerRow 
              key={player.id} 
              isWinner={index === 0}
            >
              <Position>{index + 1}</Position>
              <PlayerAvatar>{player.name.charAt(0).toUpperCase()}</PlayerAvatar>
              <PlayerName isWinner={index === 0}>
                {player.name}
                {index === 0 && <WinnerTrophy>🏆</WinnerTrophy>}
              </PlayerName>
              <PlayerScore isWinner={index === 0}>{player.score} pts</PlayerScore>
            </PlayerRow>
          ))}
        </LeaderboardContainer>
        
        <ButtonsContainer>
          <SecondaryButton onClick={handleLeaveRoom}>
            Leave Room
          </SecondaryButton>
          {user.id === room.hostId && (
            <PrimaryButton onClick={handlePlayAgain}>
              Play Again
            </PrimaryButton>
          )}
        </ButtonsContainer>
      </ResultsCard>
    </ResultsContainer>
  );
};

export default Results;
