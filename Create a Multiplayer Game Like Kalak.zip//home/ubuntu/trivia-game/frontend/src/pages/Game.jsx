import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { useSocket } from '../context/SocketContext';
import { useGame } from '../context/GameContext';

const GameContainer = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  padding: 20px;
  background: linear-gradient(135deg, #1a73e8 0%, #0d47a1 100%);
`;

const GameCard = styled.div`
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
  padding: 2rem;
  margin: 1rem auto;
  width: 100%;
  max-width: 800px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`;

const RoundInfo = styled.div`
  font-size: 1.2rem;
  font-weight: bold;
`;

const Timer = styled.div`
  font-size: 1.5rem;
  font-weight: bold;
  color: ${props => props.timeLeft < 10 ? '#e53935' : '#333'};
`;

const QuestionCard = styled.div`
  background-color: #f5f5f5;
  border-radius: 8px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
`;

const QuestionText = styled.div`
  font-size: 1.3rem;
  font-weight: bold;
  margin-bottom: 1.5rem;
  text-align: center;
`;

const OptionsGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  
  @media (max-width: 600px) {
    grid-template-columns: 1fr;
  }
`;

const OptionButton = styled.button`
  background-color: ${props => 
    props.selected ? '#e3f2fd' : 
    props.correct ? '#c8e6c9' : 
    props.incorrect ? '#ffcdd2' : 
    'white'};
  border: 2px solid ${props => 
    props.selected ? '#1a73e8' : 
    props.correct ? '#43a047' : 
    props.incorrect ? '#e53935' : 
    '#ddd'};
  border-radius: 8px;
  padding: 1rem;
  font-size: 1rem;
  text-align: left;
  cursor: ${props => props.disabled ? 'default' : 'pointer'};
  transition: all 0.2s;
  
  &:hover {
    background-color: ${props => 
      props.selected ? '#e3f2fd' : 
      props.correct ? '#c8e6c9' : 
      props.incorrect ? '#ffcdd2' : 
      props.disabled ? 'white' : '#f1f1f1'};
  }
`;

const PlayersSection = styled.div`
  margin-bottom: 1rem;
`;

const PlayersGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 0.5rem;
`;

const PlayerCard = styled.div`
  background-color: #f5f5f5;
  border-radius: 8px;
  padding: 0.8rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const PlayerAvatar = styled.div`
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background-color: #1a73e8;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 0.8rem;
`;

const PlayerInfo = styled.div`
  flex: 1;
`;

const PlayerName = styled.div`
  font-size: 0.9rem;
  font-weight: ${props => props.isHost ? 'bold' : 'normal'};
`;

const PlayerScore = styled.div`
  font-size: 0.8rem;
  color: #666;
`;

const AnswerStatus = styled.div`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background-color: ${props => props.answered ? '#43a047' : '#bdbdbd'};
`;

const ResultsCard = styled.div`
  background-color: #f5f5f5;
  border-radius: 8px;
  padding: 1.5rem;
  margin-top: 1rem;
  text-align: center;
`;

const ResultsTitle = styled.div`
  font-size: 1.3rem;
  font-weight: bold;
  margin-bottom: 1rem;
`;

const CorrectAnswer = styled.div`
  font-size: 1.1rem;
  margin-bottom: 1rem;
  color: #43a047;
  font-weight: bold;
`;

const ResultsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 1rem;
  margin-top: 1rem;
`;

const PlayerResult = styled.div`
  background-color: white;
  border-radius: 8px;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const PlayerPoints = styled.div`
  font-size: 1.5rem;
  font-weight: bold;
  color: ${props => props.points > 0 ? '#43a047' : '#666'};
  margin-top: 0.5rem;
`;

const NextRoundButton = styled.button`
  background-color: #f8c630;
  color: #333;
  border: none;
  border-radius: 8px;
  padding: 12px 24px;
  font-size: 1rem;
  font-weight: bold;
  margin-top: 1.5rem;
  cursor: pointer;
  
  &:hover {
    background-color: #e0b01f;
  }
`;

const Game = () => {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const { socket, user, submitAnswer } = useSocket();
  const { 
    room, 
    gameState, 
    currentQuestion, 
    roundResults,
    setError 
  } = useGame();
  
  const [selectedOption, setSelectedOption] = useState(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [showResults, setShowResults] = useState(false);
  
  // Redirect if not in a game
  useEffect(() => {
    if (!socket || !user || !room) {
      navigate('/');
    }
  }, [socket, user, room, navigate]);
  
  // Handle game state changes
  useEffect(() => {
    if (!gameState || !currentQuestion) return;
    
    // Reset state for new question
    setSelectedOption(null);
    setHasAnswered(false);
    setShowResults(false);
    
    // Set timer
    setTimeLeft(gameState.roundTime);
    
    // Timer countdown
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [gameState, currentQuestion]);
  
  // Handle round results
  useEffect(() => {
    if (roundResults) {
      setShowResults(true);
    }
  }, [roundResults]);
  
  // Handle answer submission
  const handleSelectOption = async (option) => {
    if (hasAnswered || timeLeft === 0) return;
    
    setSelectedOption(option);
    setHasAnswered(true);
    
    try {
      await submitAnswer(roomId, option);
    } catch (err) {
      setError(err.message || 'Failed to submit answer');
      setHasAnswered(false);
    }
  };
  
  if (!gameState || !currentQuestion) {
    return (
      <GameContainer>
        <GameCard>
          <div style={{ textAlign: 'center' }}>Loading game...</div>
        </GameCard>
      </GameContainer>
    );
  }
  
  return (
    <GameContainer>
      <GameCard>
        <Header>
          <RoundInfo>Round {gameState.currentRound}/{gameState.totalRounds}</RoundInfo>
          <Timer timeLeft={timeLeft}>{timeLeft}s</Timer>
        </Header>
        
        {!showResults ? (
          <QuestionCard>
            <QuestionText>{currentQuestion.text}</QuestionText>
            <OptionsGrid>
              {currentQuestion.options.map((option, index) => (
                <OptionButton
                  key={index}
                  selected={selectedOption === option}
                  disabled={hasAnswered || timeLeft === 0}
                  onClick={() => handleSelectOption(option)}
                >
                  {option}
                </OptionButton>
              ))}
            </OptionsGrid>
          </QuestionCard>
        ) : (
          <ResultsCard>
            <ResultsTitle>Round Results</ResultsTitle>
            <CorrectAnswer>
              Correct Answer: {roundResults.correctAnswer}
            </CorrectAnswer>
            
            <ResultsGrid>
              {Object.entries(roundResults.playerResults).map(([playerId, result]) => {
                const player = room.players.find(p => p.id === playerId);
                if (!player) return null;
                
                return (
                  <PlayerResult key={playerId}>
                    <PlayerAvatar>{player.username.charAt(0).toUpperCase()}</PlayerAvatar>
                    <PlayerName>{player.username}</PlayerName>
                    {result.answered ? (
                      <>
                        <div>{result.correct ? '✓ Correct' : '✗ Wrong'}</div>
                        <PlayerPoints points={result.points}>
                          +{result.points} pts
                        </PlayerPoints>
                      </>
                    ) : (
                      <div>No answer</div>
                    )}
                  </PlayerResult>
                );
              })}
            </ResultsGrid>
            
            {user.id === room.hostId && (
              <div style={{ textAlign: 'center', marginTop: '1rem' }}>
                Next round starting soon...
              </div>
            )}
          </ResultsCard>
        )}
        
        <PlayersSection>
          <h3>Players</h3>
          <PlayersGrid>
            {room.players.map(player => (
              <PlayerCard key={player.id}>
                <PlayerAvatar>{player.username.charAt(0).toUpperCase()}</PlayerAvatar>
                <PlayerInfo>
                  <PlayerName isHost={player.id === room.hostId}>
                    {player.username}
                  </PlayerName>
                  <PlayerScore>
                    Score: {gameState.scores[player.id] || 0}
                  </PlayerScore>
                </PlayerInfo>
                <AnswerStatus 
                  answered={
                    player.id === user.id 
                      ? hasAnswered 
                      : player.hasAnswered
                  } 
                />
              </PlayerCard>
            ))}
          </PlayersGrid>
        </PlayersSection>
      </GameCard>
    </GameContainer>
  );
};

export default Game;
