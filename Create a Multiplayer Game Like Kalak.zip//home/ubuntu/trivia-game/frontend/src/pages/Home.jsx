import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { useSocket } from '../context/SocketContext';

const HomeContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  padding: 20px;
  background: linear-gradient(135deg, #1a73e8 0%, #0d47a1 100%);
`;

const Logo = styled.div`
  font-size: 3rem;
  font-weight: bold;
  color: white;
  margin-bottom: 2rem;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
`;

const Card = styled.div`
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
  padding: 2rem;
  width: 100%;
  max-width: 500px;
`;

const Title = styled.h1`
  font-size: 1.8rem;
  margin-bottom: 1.5rem;
  text-align: center;
  color: #333;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const Input = styled.input`
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
`;

const Button = styled.button`
  padding: 12px;
  background-color: #f8c630;
  color: #333;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: bold;
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #e0b01f;
  }
`;

const TabContainer = styled.div`
  display: flex;
  margin-bottom: 1.5rem;
`;

const Tab = styled.button`
  flex: 1;
  padding: 10px;
  background-color: ${props => props.active ? '#f8c630' : '#f1f1f1'};
  color: #333;
  border: none;
  font-weight: ${props => props.active ? 'bold' : 'normal'};
  cursor: pointer;
  transition: background-color 0.3s;

  &:first-child {
    border-top-left-radius: 8px;
    border-bottom-left-radius: 8px;
  }

  &:last-child {
    border-top-right-radius: 8px;
    border-bottom-right-radius: 8px;
  }

  &:hover {
    background-color: ${props => props.active ? '#e0b01f' : '#e5e5e5'};
  }
`;

const ErrorMessage = styled.div`
  color: #e53935;
  margin-top: 0.5rem;
  text-align: center;
`;

const Select = styled.select`
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  background-color: white;
`;

const Label = styled.label`
  font-weight: bold;
  margin-bottom: -0.5rem;
`;

const Home = () => {
  const [activeTab, setActiveTab] = useState('join');
  const [username, setUsername] = useState('');
  const [roomId, setRoomId] = useState('');
  const [maxPlayers, setMaxPlayers] = useState(10);
  const [roundTime, setRoundTime] = useState(30);
  const [rounds, setRounds] = useState(10);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { registerUser, createRoom, joinRoom } = useSocket();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!username.trim()) {
      setError('Please enter a username');
      setLoading(false);
      return;
    }

    try {
      // Register user first
      await registerUser(username);

      if (activeTab === 'join') {
        // Join existing room
        if (!roomId.trim()) {
          setError('Please enter a room ID');
          setLoading(false);
          return;
        }

        const response = await joinRoom(roomId);
        navigate(`/lobby/${response.room.id}`);
      } else {
        // Create new room
        const settings = {
          maxPlayers,
          roundTime,
          rounds,
          categories: ['general'] // Default category
        };

        const response = await createRoom({ settings });
        navigate(`/lobby/${response.roomId}`);
      }
    } catch (err) {
      setError(err.message || 'An error occurred');
      setLoading(false);
    }
  };

  return (
    <HomeContainer>
      <Logo>Enhanced Trivia Game</Logo>
      <Card>
        <Title>Welcome to Trivia Challenge!</Title>
        <TabContainer>
          <Tab 
            active={activeTab === 'join'} 
            onClick={() => setActiveTab('join')}
          >
            Join Game
          </Tab>
          <Tab 
            active={activeTab === 'create'} 
            onClick={() => setActiveTab('create')}
          >
            Create Game
          </Tab>
        </TabContainer>

        <Form onSubmit={handleSubmit}>
          <Input
            type="text"
            placeholder="Your Name"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            maxLength={12}
          />

          {activeTab === 'join' ? (
            <Input
              type="text"
              placeholder="Room ID"
              value={roomId}
              onChange={(e) => setRoomId(e.target.value.toUpperCase())}
              maxLength={6}
            />
          ) : (
            <>
              <Label>Players (max 10)</Label>
              <Select 
                value={maxPlayers} 
                onChange={(e) => setMaxPlayers(Number(e.target.value))}
              >
                {[2, 3, 4, 5, 6, 7, 8, 9, 10].map(num => (
                  <option key={num} value={num}>{num}</option>
                ))}
              </Select>

              <Label>Round Time (seconds)</Label>
              <Select 
                value={roundTime} 
                onChange={(e) => setRoundTime(Number(e.target.value))}
              >
                {[15, 30, 60, 90].map(time => (
                  <option key={time} value={time}>{time}</option>
                ))}
              </Select>

              <Label>Number of Rounds</Label>
              <Select 
                value={rounds} 
                onChange={(e) => setRounds(Number(e.target.value))}
              >
                {[5, 10, 15, 20].map(num => (
                  <option key={num} value={num}>{num}</option>
                ))}
              </Select>
            </>
          )}

          <Button type="submit" disabled={loading}>
            {loading ? 'Loading...' : activeTab === 'join' ? 'Join Game' : 'Create Game'}
          </Button>

          {error && <ErrorMessage>{error}</ErrorMessage>}
        </Form>
      </Card>
    </HomeContainer>
  );
};

export default Home;
