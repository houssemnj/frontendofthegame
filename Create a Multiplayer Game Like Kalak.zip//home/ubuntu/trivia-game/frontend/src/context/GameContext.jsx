import React, { createContext, useContext, useState, useEffect } from 'react';
import { useSocket } from './SocketContext';

const GameContext = createContext();

export const useGame = () => useContext(GameContext);

export const GameProvider = ({ children }) => {
  const { socket } = useSocket();
  const [room, setRoom] = useState(null);
  const [gameState, setGameState] = useState(null);
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [roundResults, setRoundResults] = useState(null);
  const [finalResults, setFinalResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!socket) return;

    // Listen for player joining the room
    socket.on('player-joined', ({ user, room }) => {
      setRoom(room);
    });

    // Listen for player leaving the room
    socket.on('player-left', ({ playerId, room }) => {
      setRoom(room);
    });

    // Listen for game started event
    socket.on('game-started', (gameState) => {
      setGameState(gameState);
      setCurrentQuestion(gameState.question);
      setRoundResults(null);
      setFinalResults(null);
    });

    // Listen for round started event
    socket.on('round-started', (roundState) => {
      if (roundState.status === 'playing') {
        setGameState(roundState);
        setCurrentQuestion(roundState.question);
        setRoundResults(null);
      } else if (roundState.status === 'finished') {
        setGameState({ ...gameState, status: 'finished' });
      }
    });

    // Listen for round ended event
    socket.on('round-ended', (results) => {
      setRoundResults(results);
    });

    // Listen for game ended event
    socket.on('game-ended', (results) => {
      setFinalResults(results);
      setGameState({ ...gameState, status: 'finished' });
    });

    // Listen for player answered event (for host only)
    socket.on('player-answered', ({ playerId }) => {
      // Update UI to show that a player has answered
      setRoom((prevRoom) => {
        if (!prevRoom) return prevRoom;
        
        const updatedPlayers = prevRoom.players.map(player => {
          if (player.id === playerId) {
            return { ...player, hasAnswered: true };
          }
          return player;
        });
        
        return {
          ...prevRoom,
          players: updatedPlayers
        };
      });
    });

    // Clean up event listeners on unmount
    return () => {
      socket.off('player-joined');
      socket.off('player-left');
      socket.off('game-started');
      socket.off('round-started');
      socket.off('round-ended');
      socket.off('game-ended');
      socket.off('player-answered');
    };
  }, [socket, gameState]);

  // Reset game state
  const resetGame = () => {
    setGameState(null);
    setCurrentQuestion(null);
    setRoundResults(null);
    setFinalResults(null);
  };

  return (
    <GameContext.Provider
      value={{
        room,
        setRoom,
        gameState,
        currentQuestion,
        roundResults,
        finalResults,
        loading,
        setLoading,
        error,
        setError,
        resetGame
      }}
    >
      {children}
    </GameContext.Provider>
  );
};
