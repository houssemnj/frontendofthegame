import React, { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';

const SocketContext = createContext();

export const useSocket = () => useContext(SocketContext);

export const SocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Get the current hostname to determine if we're in production or development
    const isProduction = window.location.hostname !== 'localhost';
    
    // Use the appropriate backend URL based on environment
    const backendUrl = isProduction 
      ? 'https://3001-ij7fhc53r8tezwucy75l4-167c4dde.manus.computer'
      : 'http://localhost:3001';
    
    console.log('Connecting to backend at:', backendUrl);
    
    // Create socket connection
    const newSocket = io(backendUrl, {
      transports: ['websocket'],
      autoConnect: true,
      withCredentials: true,
    });

    // Set up event listeners
    newSocket.on('connect', () => {
      console.log('Connected to server');
      setConnected(true);
    });

    newSocket.on('disconnect', () => {
      console.log('Disconnected from server');
      setConnected(false);
    });

    newSocket.on('connect_error', (error) => {
      console.error('Connection error:', error);
      setConnected(false);
    });

    // Save socket to state
    setSocket(newSocket);

    // Clean up on unmount
    return () => {
      newSocket.disconnect();
    };
  }, []);

  // Register user with the server
  const registerUser = (username) => {
    return new Promise((resolve, reject) => {
      if (!socket || !connected) {
        reject(new Error('Not connected to server'));
        return;
      }

      socket.emit('register', { username }, (response) => {
        if (response.success) {
          setUser(response.user);
          resolve(response.user);
        } else {
          reject(new Error(response.error || 'Failed to register user'));
        }
      });
    });
  };

  // Create a new game room
  const createRoom = (settings) => {
    return new Promise((resolve, reject) => {
      if (!socket || !connected) {
        reject(new Error('Not connected to server'));
        return;
      }

      socket.emit('create-room', { settings }, (response) => {
        if (response.success) {
          resolve(response);
        } else {
          reject(new Error(response.error || 'Failed to create room'));
        }
      });
    });
  };

  // Join an existing game room
  const joinRoom = (roomId) => {
    return new Promise((resolve, reject) => {
      if (!socket || !connected) {
        reject(new Error('Not connected to server'));
        return;
      }

      socket.emit('join-room', { roomId }, (response) => {
        if (response.success) {
          resolve(response);
        } else {
          reject(new Error(response.error || 'Failed to join room'));
        }
      });
    });
  };

  // Start the game
  const startGame = (roomId) => {
    return new Promise((resolve, reject) => {
      if (!socket || !connected) {
        reject(new Error('Not connected to server'));
        return;
      }

      socket.emit('start-game', { roomId }, (response) => {
        if (response.success) {
          resolve(response);
        } else {
          reject(new Error(response.error || 'Failed to start game'));
        }
      });
    });
  };

  // Submit an answer
  const submitAnswer = (roomId, answer) => {
    return new Promise((resolve, reject) => {
      if (!socket || !connected) {
        reject(new Error('Not connected to server'));
        return;
      }

      socket.emit('submit-answer', { roomId, answer }, (response) => {
        if (response.success) {
          resolve(response);
        } else {
          reject(new Error(response.error || 'Failed to submit answer'));
        }
      });
    });
  };

  // Leave a room
  const leaveRoom = (roomId) => {
    return new Promise((resolve, reject) => {
      if (!socket || !connected) {
        reject(new Error('Not connected to server'));
        return;
      }

      socket.emit('leave-room', { roomId }, (response) => {
        if (response.success) {
          resolve(response);
        } else {
          reject(new Error(response.error || 'Failed to leave room'));
        }
      });
    });
  };

  return (
    <SocketContext.Provider
      value={{
        socket,
        connected,
        user,
        registerUser,
        createRoom,
        joinRoom,
        startGame,
        submitAnswer,
        leaveRoom,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
};
