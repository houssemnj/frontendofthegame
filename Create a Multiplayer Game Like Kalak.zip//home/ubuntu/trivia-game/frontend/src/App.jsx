import React from 'react';
import { Routes, Route } from 'react-router-dom';
import styled from 'styled-components';
import { SocketProvider } from './context/SocketContext';
import { GameProvider } from './context/GameContext';
import Home from './pages/Home';
import Lobby from './pages/Lobby';
import Game from './pages/Game';
import Results from './pages/Results';

const AppContainer = styled.div`
  min-height: 100vh;
  display: flex;
  flex-direction: column;
`;

const App = () => {
  return (
    <SocketProvider>
      <GameProvider>
        <AppContainer>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/lobby/:roomId" element={<Lobby />} />
            <Route path="/game/:roomId" element={<Game />} />
            <Route path="/results/:roomId" element={<Results />} />
          </Routes>
        </AppContainer>
      </GameProvider>
    </SocketProvider>
  );
};

export default App;
