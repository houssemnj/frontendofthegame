#!/bin/bash

# Start the AI service
cd /home/ubuntu/trivia-game/ai-service
echo "Starting AI Question Service..."
uvicorn app:app --host 0.0.0.0 --port 5000 &
AI_PID=$!

# Wait for AI service to start
sleep 3
echo "AI Question Service started with PID: $AI_PID"

# Start the backend server
cd /home/ubuntu/trivia-game/backend
echo "Starting Backend Server..."
node server.js &
BACKEND_PID=$!

echo "Backend Server started with PID: $BACKEND_PID"
echo "Both services are now running!"
echo "AI Service: http://localhost:5000"
echo "Backend Server: http://localhost:3001"

# Keep script running
wait
