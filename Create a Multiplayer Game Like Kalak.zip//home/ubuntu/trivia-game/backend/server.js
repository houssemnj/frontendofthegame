const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const axios = require('axios');

// Load environment variables
dotenv.config();

// Initialize Express app
const app = express();
app.use(cors());
app.use(express.json());

// Create HTTP server
const server = http.createServer(app);

// Initialize Socket.io
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// MongoDB connection (commented out until we have actual MongoDB URI)
// mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/trivia-game')
//   .then(() => console.log('Connected to MongoDB'))
//   .catch(err => console.error('MongoDB connection error:', err));

// In-memory data store (for development)
const rooms = new Map();
const users = new Map();

// AI Question Service URL (will be implemented later)
const AI_SERVICE_URL = process.env.AI_SERVICE_URL || 'http://localhost:5000';

// Room model
class Room {
  constructor(id, hostId, settings = {}) {
    this.id = id;
    this.hostId = hostId;
    this.players = new Map();
    this.settings = {
      maxPlayers: settings.maxPlayers || 10,
      roundTime: settings.roundTime || 30,
      rounds: settings.rounds || 10,
      categories: settings.categories || ['general']
    };
    this.gameState = {
      status: 'waiting', // waiting, playing, finished
      currentRound: 0,
      currentQuestion: null,
      answers: new Map(),
      scores: new Map(),
      roundStartTime: null
    };
    this.questions = [];
  }

  addPlayer(player) {
    if (this.players.size >= this.settings.maxPlayers) {
      return false;
    }
    this.players.set(player.id, player);
    this.gameState.scores.set(player.id, 0);
    return true;
  }

  removePlayer(playerId) {
    this.players.delete(playerId);
    this.gameState.scores.delete(playerId);
    // If host leaves, assign new host
    if (playerId === this.hostId && this.players.size > 0) {
      this.hostId = Array.from(this.players.keys())[0];
    }
    return this.players.size;
  }

  submitAnswer(playerId, answer) {
    if (this.gameState.status !== 'playing') return false;
    
    const currentTime = Date.now();
    const timeTaken = (currentTime - this.gameState.roundStartTime) / 1000;
    
    if (timeTaken > this.settings.roundTime) return false;
    
    this.gameState.answers.set(playerId, {
      answer,
      timeTaken
    });
    
    return true;
  }

  async startGame() {
    if (this.players.size < 2) return false;
    
    this.gameState.status = 'playing';
    this.gameState.currentRound = 0;
    this.gameState.scores = new Map();
    this.players.forEach(player => {
      this.gameState.scores.set(player.id, 0);
    });
    
    // Pre-fetch first batch of questions
    await this.fetchQuestions();
    
    return this.startNextRound();
  }

  async startNextRound() {
    if (this.gameState.currentRound >= this.settings.rounds) {
      this.gameState.status = 'finished';
      return {
        status: 'finished',
        scores: Object.fromEntries(this.gameState.scores)
      };
    }
    
    this.gameState.currentRound++;
    this.gameState.answers = new Map();
    
    // Get next question
    if (this.questions.length === 0) {
      await this.fetchQuestions();
    }
    
    this.gameState.currentQuestion = this.questions.shift();
    this.gameState.roundStartTime = Date.now();
    
    return {
      status: 'playing',
      round: this.gameState.currentRound,
      question: {
        text: this.gameState.currentQuestion.text,
        options: this.gameState.currentQuestion.options
      },
      roundTime: this.settings.roundTime
    };
  }

  async fetchQuestions(count = 5) {
    try {
      // In a real implementation, this would call the AI service
      // For now, we'll use placeholder questions
      const placeholderQuestions = [
        {
          text: "What is the capital of France?",
          options: ["Paris", "London", "Berlin", "Madrid"],
          correctAnswer: "Paris",
          category: "geography"
        },
        {
          text: "Who wrote 'Romeo and Juliet'?",
          options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"],
          correctAnswer: "William Shakespeare",
          category: "literature"
        },
        {
          text: "What is the largest planet in our solar system?",
          options: ["Earth", "Mars", "Jupiter", "Venus"],
          correctAnswer: "Jupiter",
          category: "science"
        },
        {
          text: "What year did World War II end?",
          options: ["1943", "1944", "1945", "1946"],
          correctAnswer: "1945",
          category: "history"
        },
        {
          text: "Which element has the chemical symbol 'O'?",
          options: ["Gold", "Oxygen", "Osmium", "Oganesson"],
          correctAnswer: "Oxygen",
          category: "science"
        }
      ];
      
      // In the future, we'll replace this with actual API calls to the AI service
      // const response = await axios.post(`${AI_SERVICE_URL}/generate-questions`, {
      //   categories: this.settings.categories,
      //   count
      // });
      // this.questions.push(...response.data.questions);
      
      this.questions.push(...placeholderQuestions);
      
    } catch (error) {
      console.error('Error fetching questions:', error);
      // Fallback to basic questions if AI service fails
      this.questions.push({
        text: "What is 2 + 2?",
        options: ["3", "4", "5", "6"],
        correctAnswer: "4",
        category: "general"
      });
    }
  }

  evaluateRound() {
    if (this.gameState.status !== 'playing') return null;
    
    const results = {
      correctAnswer: this.gameState.currentQuestion.correctAnswer,
      playerResults: {}
    };
    
    this.players.forEach(player => {
      const playerAnswer = this.gameState.answers.get(player.id);
      
      if (!playerAnswer) {
        results.playerResults[player.id] = {
          answered: false,
          correct: false,
          points: 0
        };
        return;
      }
      
      const isCorrect = playerAnswer.answer === this.gameState.currentQuestion.correctAnswer;
      
      // Calculate points: max 100 points, decreasing with time taken
      let points = 0;
      if (isCorrect) {
        const timeRatio = Math.max(0, 1 - (playerAnswer.timeTaken / this.settings.roundTime));
        points = Math.round(100 * timeRatio);
        
        // Update player score
        const currentScore = this.gameState.scores.get(player.id) || 0;
        this.gameState.scores.set(player.id, currentScore + points);
      }
      
      results.playerResults[player.id] = {
        answered: true,
        answer: playerAnswer.answer,
        correct: isCorrect,
        timeTaken: playerAnswer.timeTaken,
        points
      };
    });
    
    return results;
  }

  getGameState() {
    return {
      id: this.id,
      hostId: this.hostId,
      players: Array.from(this.players.values()),
      settings: this.settings,
      gameState: {
        status: this.gameState.status,
        currentRound: this.gameState.currentRound,
        scores: Object.fromEntries(this.gameState.scores),
        totalRounds: this.settings.rounds
      }
    };
  }
}

// Socket.io event handlers
io.on('connection', (socket) => {
  console.log(`User connected: ${socket.id}`);
  
  // Create a new user
  socket.on('register', ({ username }, callback) => {
    const user = {
      id: socket.id,
      username: username || `Player_${socket.id.substr(0, 5)}`,
      avatar: Math.floor(Math.random() * 10) // Random avatar for now
    };
    
    users.set(socket.id, user);
    
    callback({
      success: true,
      user
    });
  });
  
  // Create a new room
  socket.on('create-room', ({ settings }, callback) => {
    const user = users.get(socket.id);
    if (!user) {
      callback({ success: false, error: 'User not registered' });
      return;
    }
    
    const roomId = generateRoomId();
    const room = new Room(roomId, socket.id, settings);
    room.addPlayer(user);
    rooms.set(roomId, room);
    
    // Join socket room
    socket.join(roomId);
    
    callback({
      success: true,
      roomId,
      room: room.getGameState()
    });
  });
  
  // Join an existing room
  socket.on('join-room', ({ roomId }, callback) => {
    const user = users.get(socket.id);
    if (!user) {
      callback({ success: false, error: 'User not registered' });
      return;
    }
    
    const room = rooms.get(roomId);
    if (!room) {
      callback({ success: false, error: 'Room not found' });
      return;
    }
    
    const joined = room.addPlayer(user);
    if (!joined) {
      callback({ success: false, error: 'Room is full' });
      return;
    }
    
    // Join socket room
    socket.join(roomId);
    
    // Notify all players in the room
    io.to(roomId).emit('player-joined', {
      user,
      room: room.getGameState()
    });
    
    callback({
      success: true,
      room: room.getGameState()
    });
  });
  
  // Start game
  socket.on('start-game', async ({ roomId }, callback) => {
    const room = rooms.get(roomId);
    if (!room) {
      callback({ success: false, error: 'Room not found' });
      return;
    }
    
    if (room.hostId !== socket.id) {
      callback({ success: false, error: 'Only host can start the game' });
      return;
    }
    
    const gameState = await room.startGame();
    if (!gameState) {
      callback({ success: false, error: 'Failed to start game' });
      return;
    }
    
    // Notify all players
    io.to(roomId).emit('game-started', gameState);
    
    // Set timer for round end
    setTimeout(() => {
      const results = room.evaluateRound();
      io.to(roomId).emit('round-ended', results);
      
      // Start next round after a delay
      setTimeout(async () => {
        const nextRound = await room.startNextRound();
        io.to(roomId).emit('round-started', nextRound);
        
        if (nextRound.status === 'finished') {
          io.to(roomId).emit('game-ended', {
            scores: Object.fromEntries(room.gameState.scores)
          });
        }
      }, 5000); // 5 seconds between rounds
      
    }, room.settings.roundTime * 1000);
    
    callback({ success: true });
  });
  
  // Submit answer
  socket.on('submit-answer', ({ roomId, answer }, callback) => {
    const room = rooms.get(roomId);
    if (!room) {
      callback({ success: false, error: 'Room not found' });
      return;
    }
    
    const submitted = room.submitAnswer(socket.id, answer);
    if (!submitted) {
      callback({ success: false, error: 'Failed to submit answer' });
      return;
    }
    
    // Notify host about answer submission (not the answer itself)
    socket.to(room.hostId).emit('player-answered', {
      playerId: socket.id
    });
    
    callback({ success: true });
  });
  
  // Leave room
  socket.on('leave-room', ({ roomId }, callback) => {
    const room = rooms.get(roomId);
    if (!room) {
      callback({ success: false, error: 'Room not found' });
      return;
    }
    
    const remainingPlayers = room.removePlayer(socket.id);
    
    // Leave socket room
    socket.leave(roomId);
    
    // If room is empty, delete it
    if (remainingPlayers === 0) {
      rooms.delete(roomId);
    } else {
      // Notify remaining players
      io.to(roomId).emit('player-left', {
        playerId: socket.id,
        room: room.getGameState()
      });
    }
    
    callback({ success: true });
  });
  
  // Disconnect
  socket.on('disconnect', () => {
    console.log(`User disconnected: ${socket.id}`);
    
    // Remove user from all rooms
    rooms.forEach((room, roomId) => {
      if (room.players.has(socket.id)) {
        const remainingPlayers = room.removePlayer(socket.id);
        
        // If room is empty, delete it
        if (remainingPlayers === 0) {
          rooms.delete(roomId);
        } else {
          // Notify remaining players
          io.to(roomId).emit('player-left', {
            playerId: socket.id,
            room: room.getGameState()
          });
        }
      }
    });
    
    // Remove user
    users.delete(socket.id);
  });
});

// Helper function to generate room ID
function generateRoomId() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

// API routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.get('/api/rooms', (req, res) => {
  const roomList = Array.from(rooms.values()).map(room => ({
    id: room.id,
    playerCount: room.players.size,
    maxPlayers: room.settings.maxPlayers,
    status: room.gameState.status
  }));
  
  res.json({ rooms: roomList });
});

// Start server
const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = { app, server };
