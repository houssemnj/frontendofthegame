import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import random
import json
import openai
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize FastAPI app
app = FastAPI(title="AI Trivia Question Generator")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure OpenAI API (commented out until we have actual API key)
# openai.api_key = os.getenv("OPENAI_API_KEY")

# Models
class QuestionRequest(BaseModel):
    categories: List[str]
    count: int = 5
    difficulty: Optional[str] = "medium"  # easy, medium, hard

class QuestionOption(BaseModel):
    text: str
    isCorrect: bool

class Question(BaseModel):
    text: str
    options: List[str]
    correctAnswer: str
    category: str
    difficulty: str

class QuestionResponse(BaseModel):
    questions: List[Question]

# Sample categories and questions for development
SAMPLE_CATEGORIES = {
    "general": [
        {
            "text": "What is the capital of France?",
            "options": ["Paris", "London", "Berlin", "Madrid"],
            "correctAnswer": "Paris",
            "difficulty": "easy"
        },
        {
            "text": "Who painted the Mona Lisa?",
            "options": ["Leonardo da Vinci", "Pablo Picasso", "Vincent van Gogh", "Michelangelo"],
            "correctAnswer": "Leonardo da Vinci",
            "difficulty": "easy"
        }
    ],
    "science": [
        {
            "text": "What is the chemical symbol for gold?",
            "options": ["Au", "Ag", "Fe", "Gd"],
            "correctAnswer": "Au",
            "difficulty": "medium"
        },
        {
            "text": "What is the largest planet in our solar system?",
            "options": ["Jupiter", "Saturn", "Neptune", "Earth"],
            "correctAnswer": "Jupiter",
            "difficulty": "easy"
        }
    ],
    "history": [
        {
            "text": "In which year did World War II end?",
            "options": ["1945", "1944", "1946", "1943"],
            "correctAnswer": "1945",
            "difficulty": "medium"
        },
        {
            "text": "Who was the first president of the United States?",
            "options": ["George Washington", "Thomas Jefferson", "Abraham Lincoln", "John Adams"],
            "correctAnswer": "George Washington",
            "difficulty": "easy"
        }
    ],
    "geography": [
        {
            "text": "Which is the largest ocean on Earth?",
            "options": ["Pacific Ocean", "Atlantic Ocean", "Indian Ocean", "Arctic Ocean"],
            "correctAnswer": "Pacific Ocean",
            "difficulty": "medium"
        },
        {
            "text": "What is the longest river in the world?",
            "options": ["Nile", "Amazon", "Yangtze", "Mississippi"],
            "correctAnswer": "Nile",
            "difficulty": "medium"
        }
    ],
    "sports": [
        {
            "text": "In which sport would you perform a slam dunk?",
            "options": ["Basketball", "Volleyball", "Tennis", "Football"],
            "correctAnswer": "Basketball",
            "difficulty": "easy"
        },
        {
            "text": "How many players are there in a standard soccer team?",
            "options": ["11", "10", "12", "9"],
            "correctAnswer": "11",
            "difficulty": "easy"
        }
    ],
    "entertainment": [
        {
            "text": "Who played Iron Man in the Marvel Cinematic Universe?",
            "options": ["Robert Downey Jr.", "Chris Evans", "Chris Hemsworth", "Mark Ruffalo"],
            "correctAnswer": "Robert Downey Jr.",
            "difficulty": "easy"
        },
        {
            "text": "Which band performed the song 'Bohemian Rhapsody'?",
            "options": ["Queen", "The Beatles", "Led Zeppelin", "Pink Floyd"],
            "correctAnswer": "Queen",
            "difficulty": "easy"
        }
    ]
}

# AI-based question generation function
async def generate_ai_questions(categories, count, difficulty):
    """
    Generate questions using AI (OpenAI API)
    In a production environment, this would call the OpenAI API
    """
    try:
        # This is where we would call the OpenAI API in production
        # For now, we'll return placeholder questions
        
        # Example of how the OpenAI call would look:
        # response = await openai.ChatCompletion.create(
        #     model="gpt-4",
        #     messages=[
        #         {"role": "system", "content": "You are a trivia question generator."},
        #         {"role": "user", "content": f"Generate {count} {difficulty} trivia questions about {', '.join(categories)}. For each question, provide 4 options with exactly one correct answer. Format as JSON."}
        #     ]
        # )
        # 
        # # Parse the response and convert to our Question format
        # ai_generated_questions = json.loads(response.choices[0].message.content)
        
        # For now, return sample questions
        questions = []
        for _ in range(count):
            # Select a random category from the requested categories
            category = random.choice(categories)
            if category not in SAMPLE_CATEGORIES:
                category = "general"  # Default to general if category not found
                
            # Select a random question from the category
            sample_questions = [q for q in SAMPLE_CATEGORIES[category] if q["difficulty"] == difficulty]
            if not sample_questions:
                sample_questions = SAMPLE_CATEGORIES[category]  # Fall back to any difficulty
                
            question_data = random.choice(sample_questions)
            
            # Create a Question object
            question = Question(
                text=question_data["text"],
                options=question_data["options"],
                correctAnswer=question_data["correctAnswer"],
                category=category,
                difficulty=difficulty
            )
            
            questions.append(question)
            
        return questions
    except Exception as e:
        print(f"Error generating AI questions: {e}")
        # Fallback to basic questions
        return [
            Question(
                text="What is 2 + 2?",
                options=["3", "4", "5", "6"],
                correctAnswer="4",
                category="general",
                difficulty="easy"
            )
        ]

# Routes
@app.get("/")
async def root():
    return {"message": "AI Trivia Question Generator API"}

@app.post("/generate-questions", response_model=QuestionResponse)
async def generate_questions(request: QuestionRequest):
    if not request.categories:
        raise HTTPException(status_code=400, detail="At least one category must be specified")
    
    if request.count < 1 or request.count > 20:
        raise HTTPException(status_code=400, detail="Count must be between 1 and 20")
    
    questions = await generate_ai_questions(
        categories=request.categories,
        count=request.count,
        difficulty=request.difficulty
    )
    
    return QuestionResponse(questions=questions)

@app.get("/categories")
async def get_categories():
    return {"categories": list(SAMPLE_CATEGORIES.keys())}

# Run the application
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)
