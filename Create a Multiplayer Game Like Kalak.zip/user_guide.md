# Enhanced Trivia Game User Guide

## Introduction

Welcome to the Enhanced Trivia Game! This multiplayer trivia game allows you to challenge your friends with real-time AI-generated questions across various categories. With support for up to 10 players, it's perfect for game nights, team building, or just having fun with friends.

## Getting Started

### Accessing the Game

The game is accessible at: **[https://tnzjiytw.manus.space](https://tnzjiytw.manus.space)**

You can play on any device with a modern web browser - desktop, tablet, or mobile.

### Creating a Game

1. Visit the game URL
2. Enter your name in the "Your Name" field
3. Select the "Create Game" tab
4. Configure your game settings:
   - Number of players (up to 10)
   - Round time (15, 30, 60, or 90 seconds)
   - Number of rounds (5, 10, 15, or 20)
5. Click "Create Game"

### Joining a Game

1. Visit the game URL
2. Enter your name in the "Your Name" field
3. Make sure you're on the "Join Game" tab
4. Enter the Room ID provided by the game host
5. Click "Join Game"

## Game Lobby

### For Hosts

As the host, you have control over the game:
- You can see all players who join your room
- You can select trivia categories for the game
- Only you can start the game when ready
- You must have at least 2 players to start

### For Players

As a player:
- You'll see all other players in the lobby
- You can view the game settings
- You'll need to wait for the host to start the game

### Sharing Your Game

To invite friends:
1. Copy the Room ID shown in the lobby
2. Share this ID with your friends
3. They can use this ID to join your game

## Playing the Game

### Game Flow

1. Each round presents a multiple-choice question to all players
2. A timer counts down the seconds remaining to answer
3. Select your answer by clicking on one of the options
4. Points are awarded based on correct answers and speed
5. After each round, results are shown with the correct answer
6. The game automatically advances to the next round
7. After all rounds, final results and rankings are displayed

### Scoring System

- Correct answers earn points based on how quickly you respond
- The faster you answer correctly, the more points you earn
- Maximum points per question: 100
- No points are awarded for incorrect answers

## Game Features

### Real-time Updates

- See which players have answered in real-time
- View current scores throughout the game
- Experience seamless transitions between rounds

### Multiple Categories

The game includes various trivia categories:
- General Knowledge
- Science
- History
- Geography
- Entertainment
- Sports
- And more!

### Player Capacity

- Support for up to 10 players in a single game
- Minimum of 2 players required to start

## Tips for Success

1. **Read carefully**: Take time to read each question thoroughly
2. **Balance speed and accuracy**: Faster correct answers earn more points
3. **Watch the timer**: Keep an eye on the countdown
4. **Learn from results**: Pay attention to correct answers to improve your knowledge

## Troubleshooting

### Common Issues

- **Can't join a room**: Double-check the Room ID for typos
- **Game not starting**: Make sure there are at least 2 players in the room
- **Disconnection**: If disconnected, try rejoining with the same Room ID

### Browser Compatibility

The game works best on:
- Chrome (latest version)
- Firefox (latest version)
- Safari (latest version)
- Edge (latest version)

## Enjoy the Game!

Challenge your friends, test your knowledge, and have fun with the Enhanced Trivia Game. With support for up to 10 players and real-time AI-generated questions, every game is a unique experience!
